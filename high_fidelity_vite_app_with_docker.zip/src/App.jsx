import React, { useRef, useEffect, useState } from "react";
import mapboxgl from "mapbox-gl";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

const samplePlants = [
  { id: 1, name: "Capparis zeylanica", family: "Capparaceae", region: "North", status: "Published", updated: "2025-10-12", coords: [77.59, 12.97], type: "edible" },
  { id: 2, name: "Ficus religiosa", family: "Moraceae", region: "Central", status: "Pending Review", updated: "2025-11-02", coords: [77.60, 12.97], type: "medicinal" },
  { id: 3, name: "Withania somnifera", family: "Solanaceae", region: "West", status: "Draft", updated: "2025-09-29", coords: [77.595, 12.968], type: "medicinal" },
  { id: 4, name: "Ricinus communis", family: "Euphorbiaceae", region: "East", status: "Published", updated: "2025-08-11", coords: [77.592, 12.972], type: "non-edible" },
  { id: 5, name: "Moringa oleifera", family: "Moringaceae", region: "South", status: "Published", updated: "2025-07-21", coords: [77.598, 12.975], type: "edible" },
];

function Tag({ children, tone = "base" }) {
  const className = tone === "danger" ? "px-2 py-1 text-xs rounded bg-red-600/10 text-red-600" : "px-2 py-1 text-xs rounded bg-slate-800/10 text-slate-800";
  return <span className={className}>{children}</span>;
}

function createLeafletIcon(type) {
  const svgMap = {
    edible: `<svg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 24 24' fill='none'><circle cx='12' cy='12' r='10' fill='%234caf50'/></svg>`,
    medicinal: `<svg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 24 24' fill='none'><circle cx='12' cy='12' r='10' fill='%2342a5f5'/></svg>`,
    "non-edible": `<svg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 24 24' fill='none'><circle cx='12' cy='12' r='10' fill='%23f44336'/></svg>`,
  };
  const svg = svgMap[type] || svgMap["edible"];
  const dataUrl = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
  return L.divIcon({
    className: "custom-leaflet-icon",
    html: `<img src="${dataUrl}" style="width:36px;height:36px;display:block;" alt="${type}"/>`,
    iconSize: [36, 36],
    iconAnchor: [18, 36],
    popupAnchor: [0, -36],
  });
}

function addMapboxTypeIcons(map) {
  if (!map || !map.addImage) return;
  const svgMap = {
    "edible-icon": `<svg xmlns='http://www.w3.org/2000/svg' width='64' height='64' viewBox='0 0 24 24' fill='none'><circle cx='12' cy='12' r='10' fill='%234caf50'/></svg>`,
    "medicinal-icon": `<svg xmlns='http://www.w3.org/2000/svg' width='64' height='64' viewBox='0 0 24 24' fill='none'><circle cx='12' cy='12' r='10' fill='%2342a5f5'/></svg>`,
    "non-edible-icon": `<svg xmlns='http://www.w3.org/2000/svg' width='64' height='64' viewBox='0 0 24 24' fill='none'><circle cx='12' cy='12' r='10' fill='%23f44336'/></svg>`,
  };
  Object.entries(svgMap).forEach(([id, svg]) => {
    try {
      if (map.hasImage && map.hasImage(id)) return;
    } catch (e) {}
    const img = new Image();
    img.onload = () => {
      try { map.addImage(id, img); } catch (e) {}
    };
    img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
  });
}

export default function App() {
  const mapContainer = useRef(null);
  const mapRef = useRef(null);
  const leafletRef = useRef(null);
  const leafletMarkers = useRef({});
  const [mapStatus, setMapStatus] = useState("idle");
  const [mapError, setMapError] = useState("");
  const [filter, setFilter] = useState("all");

  const counts = samplePlants.reduce((acc, p) => {
    acc.total += 1;
    if (p.type === "edible") acc.edible += 1;
    else if (p.type === "medicinal") acc.medicinal += 1;
    else acc.nonEdible += 1;
    return acc;
  }, { total: 0, edible: 0, medicinal: 0, nonEdible: 0 });

  const filteredPlants = samplePlants.filter((p) => {
    if (filter === "all") return true;
    if (filter === "non-edible") return p.type === "non-edible";
    return p.type === filter;
  });

  function updateMapForFilter(currentFilter) {
    try {
      if (mapRef.current && mapRef.current.getSource && mapRef.current.getSource("plants")) {
        const data = {
          type: "FeatureCollection",
          features: samplePlants
            .filter((p) => currentFilter === "all" ? true : (currentFilter === "non-edible" ? p.type === "non-edible" : p.type === currentFilter))
            .map((p) => ({ type: "Feature", properties: { id: p.id, name: p.name, type: p.type, family: p.family, region: p.region, updated: p.updated }, geometry: { type: "Point", coordinates: [p.coords[0], p.coords[1]] } }))
        };
        mapRef.current.getSource("plants").setData(data);
      }
    } catch (e) {}

    if (leafletRef.current) {
      const map = leafletRef.current;
      Object.values(leafletMarkers.current).forEach((m) => { try { map.removeLayer(m); } catch (e) {} });
      leafletMarkers.current = {};

      samplePlants
        .filter((p) => currentFilter === "all" ? true : (currentFilter === "non-edible" ? p.type === "non-edible" : p.type === currentFilter))
        .forEach((p) => {
          const icon = createLeafletIcon(p.type);
          const marker = L.marker([p.coords[1], p.coords[0]], { icon }).addTo(map);
          marker.bindPopup(`<strong>${p.name}</strong><br/><small>${p.family} • ${p.region}</small><br/><small>Type: ${p.type}</small>`);
          leafletMarkers.current[p.id] = marker;
        });
    }
  }

  useEffect(() => {
    let mounted = true;
    const token = (typeof window !== "undefined" && window.MAPBOX_TOKEN) ? window.MAPBOX_TOKEN : "";
    const hasToken = typeof token === "string" && token.length > 20 && !token.includes("YOUR_MAPBOX_TOKEN_HERE");

  useEffect(() => {
    // ensure filter updates still work even if map not ready yet
  }, [filter]);

  function initLeaflet() {
    if (!mapContainer.current) return;
    try {
      const map = L.map(mapContainer.current, { zoomControl: false }).setView([12.9716, 77.5946], 12);
      leafletRef.current = map;
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; OpenStreetMap contributors' }).addTo(map);
      updateMapForFilter(filter);
      if (!mounted) return;
      setMapStatus("initialized");
    } catch (err) {
      console.error(err);
      if (mounted) {
        setMapStatus("error");
        setMapError(String(err.message || err));
      }
    }
  }

  function initMapbox(token) {
    if (!mapContainer.current) return;
    try {
      mapboxgl.accessToken = token;
      const map = new mapboxgl.Map({ container: mapContainer.current, style: 'mapbox://styles/mapbox/satellite-v9', center: [77.5946, 12.9716], zoom: 12 });
      mapRef.current = map;
      map.on('load', () => {
        addMapboxTypeIcons(map);
        const geojson = { type: 'FeatureCollection', features: samplePlants.map((p) => ({ type: 'Feature', properties: { id: p.id, name: p.name, type: p.type, family: p.family, region: p.region, updated: p.updated }, geometry: { type: 'Point', coordinates: [p.coords[0], p.coords[1]] } })) };
        map.addSource('plants', { type: 'geojson', data: geojson, cluster: true, clusterMaxZoom: 14, clusterRadius: 50 });
        map.addLayer({ id: 'clusters', type: 'circle', source: 'plants', filter: ['has', 'point_count'], paint: { 'circle-color': ['step', ['get', 'point_count'], '#ffd54f', 5, '#ffb74d', 10, '#fb8c00'], 'circle-radius': ['step', ['get', 'point_count'], 15, 5, 20, 10, 25] } });
        map.addLayer({ id: 'cluster-count', type: 'symbol', source: 'plants', filter: ['has', 'point_count'], layout: { 'text-field': '{point_count_abbreviated}', 'text-font': ['Open Sans Bold', 'Arial Unicode MS Bold'], 'text-size': 12 }, paint: { 'text-color': '#000' } });
        map.addLayer({ id: 'unclustered-symbol', type: 'symbol', source: 'plants', filter: ['!', ['has', 'point_count']], layout: { 'icon-image': ['concat', ['get', 'type'], '-icon'], 'icon-size': 0.6, 'icon-allow-overlap': true, 'icon-anchor': 'bottom' } });
        map.on('click', 'unclustered-symbol', (e) => {
          const feature = e.features && e.features[0];
          if (!feature) return;
          const coords = feature.geometry.coordinates.slice();
          const props = feature.properties || {};
          new mapboxgl.Popup({ offset: 12 }).setLngLat(coords).setHTML(`<strong>${props.name}</strong><br/><small>${props.family} • ${props.region}</small><br/><small>Type: ${props.type}</small>`).addTo(map);
        });
        updateMapForFilter(filter);
        if (!mounted) return;
        setMapStatus("initialized");
      });
    } catch (err) {
      console.error(err);
      if (mounted) {
        setMapStatus("error");
        setMapError(String(err.message || err));
      }
    }
  }

  useEffect(() => {
    // initialize preferred map (Mapbox if token present and mapboxgl available)
    let mounted = true;
    const token = (typeof window !== 'undefined' && window.MAPBOX_TOKEN) ? window.MAPBOX_TOKEN : '';
    const hasToken = typeof token === 'string' && token.length > 20 && !token.includes('YOUR_MAPBOX_TOKEN_HERE');
    if (hasToken && typeof mapboxgl !== 'undefined') {
      initMapbox(token);
    } else {
      initLeaflet();
    }
    return () => {
      mounted = false;
      if (mapRef.current) try { mapRef.current.remove(); } catch (e) {}
      if (leafletRef.current) try { leafletRef.current.remove(); } catch (e) {}
    };
  }, []);

  useEffect(() => {
    updateMapForFilter(filter);
  }, [filter]);

  const enterTokenAndInit = () => {
    const t = window.prompt('Enter Mapbox token for demo (or press Cancel):');
    if (!t) return;
    window.MAPBOX_TOKEN = t;
    if (leafletRef.current) { try { leafletRef.current.remove(); } catch {} }
    if (mapRef.current) { try { mapRef.current.remove(); } catch {} }
    setMapStatus('idle');
    setTimeout(() => {
      try {
        initMapbox(t);
      } catch (e) {
        setMapStatus('error');
        setMapError(String(e.message || e));
      }
    }, 250);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 p-6">
      <header className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Web GIS Dashboard & Plant Data Management</h1>
          <p className="text-sm text-slate-600">High-fidelity prototype — map and admin workflows for field & HQ use</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="px-3 py-2 rounded bg-slate-800 text-white text-sm">Export PNG</button>
          <button className="px-3 py-2 rounded border border-slate-200 text-sm">Share</button>
        </div>
      </header>

  
      <main className="grid grid-cols-12 gap-6">
        <section className="col-span-8 bg-white rounded-2xl shadow p-4 flex flex-col gap-4">
          <div className="relative h-96 rounded-lg overflow-hidden border border-slate-100">
            <div ref={mapContainer} className="absolute inset-0 h-full w-full bg-slate-100 flex items-center justify-center">
              {mapStatus !== "initialized" && (
                <div className="text-center px-4">
                  <div className="text-sm text-slate-600 mb-2">Map unavailable</div>
                  <div className="text-xs text-slate-500 mb-3">{mapError || "Map is not initialized yet."}</div>
                  <div className="flex items-center justify-center gap-2">
                    <button onClick={enterTokenAndInit} className="px-3 py-2 rounded bg-amber-600 text-white text-sm">Enter token</button>
                    <button onClick={() => alert('Tip: set window.MAPBOX_TOKEN in console before mounting for Mapbox demo')} className="px-3 py-2 rounded border text-sm">How to provide token</button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </section>
        <section className="col-span-4">
          <div className="bg-white rounded-2xl p-4 shadow">
            <h3 className="text-sm font-semibold mb-3">Filters</h3>
            <div className="flex flex-col gap-2">
              <button onClick={() => setFilter('all')} className="px-3 py-2 rounded border">All ({counts.total})</button>
              <button onClick={() => setFilter('edible')} className="px-3 py-2 rounded border">Edible ({counts.edible})</button>
              <button onClick={() => setFilter('medicinal')} className="px-3 py-2 rounded border">Medicinal ({counts.medicinal})</button>
              <button onClick={() => setFilter('non-edible')} className="px-3 py-2 rounded border">Non-edible ({counts.nonEdible})</button>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
